import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import {AddcourseComponent} from '../addcourse/addcourse.component';


const appRoutes:Routes=[
  {path:'addC', component:AddcourseComponent},
  //{path:'searchC', component:SearchComponent},
]

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(
      appRoutes,
      {enableTracing:true}
    )
  ],
  exports:[
    RouterModule
  ],
  declarations: []
})
export class RoutingModule { }