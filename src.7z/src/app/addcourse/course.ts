export class Course{
    name:string;
    duration:number
}