import { Component, OnInit } from '@angular/core';
import {Course} from './Course';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-addcourse',
  templateUrl: './addcourse.component.html',
  styleUrls: ['./addcourse.component.css']
})
export class AddcourseComponent implements OnInit {

  courses:Course[]=[
    {name:"Course 1",duration:3},
    {name:"Course 2",duration:4},
    {name:"Course 3",duration:5},
    {name:"Course 4",duration:2},
    {name:"Course 5",duration:7},
    {name:"Course 6",duration:3},
    {name:"Course 7",duration:5},
    {name:"Course 8",duration:7},
    {name:"Course 9",duration:3},
    {name:"Course 10",duration:4}
  ]
  constructor() { }

  ngOnInit() {
  }
  onSubmit(myForm:NgForm)
  {
    console.log({myForm:name})
  }
}
